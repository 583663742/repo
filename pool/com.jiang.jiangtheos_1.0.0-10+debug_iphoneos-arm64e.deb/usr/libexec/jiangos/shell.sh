#!/bin/sh
# JiangTheos shell.sh —— 构建页内置终端（root 执行）
export PATH="/var/jb/usr/bin:/var/jb/usr/sbin:/usr/bin:/usr/sbin:/bin:/sbin"
exec /bin/sh -c "$*"
