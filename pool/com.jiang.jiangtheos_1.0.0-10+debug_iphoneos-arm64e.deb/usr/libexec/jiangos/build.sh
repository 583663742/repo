#!/bin/sh
# JiangTheos build.sh —— 由 jhelper(root) 调用
# usage: build.sh <projectDir> <build|package|clean>
export PATH="/var/jb/usr/bin:/var/jb/usr/sbin:/usr/bin:/usr/sbin:/bin:/sbin"
PROJ="$1"; ACTION="$2"
[ -z "$PROJ" ] && { echo "错误: 缺少项目路径"; exit 1; }
[ -d "$PROJ" ] || { echo "错误: 项目目录不存在: $PROJ"; exit 1; }
cd "$PROJ" || exit 1
export THEOS="${THEOS:-/var/jb/theos}"
[ -f "$THEOS/makefiles/common.mk" ] || { echo "错误: 未找到 theos ($THEOS)，请先在设置页一键安装工具链"; exit 1; }
echo "== THEOS=$THEOS  ARCHS=$ARCHS  TARGET=$TARGET  SCHEME=$THEOS_PACKAGE_SCHEME =="
case "$ACTION" in
  build)   make ;;
  package) make package ;;
  clean)   make clean ;;
  *) echo "用法: build.sh <项目> <build|package|clean>"; exit 1 ;;
esac
echo "== make 退出码: $? =="
exit 0
