#import <Preferences/PSListController.h>

@interface {{NAME}}Controller : PSListController
@end

@implementation {{NAME}}Controller

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

@end
