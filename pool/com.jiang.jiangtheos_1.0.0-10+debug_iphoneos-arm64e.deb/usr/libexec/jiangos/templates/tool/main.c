#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("{{NAME}} v0.0.1\n");
    return 0;
}
