#import <Foundation/Foundation.h>

/// {{NAME}} 公共接口
@interface {{NAME}} : NSObject

+ (NSString *)greeting;

@end
