#import "{{NAME}}.h"

@implementation {{NAME}}

+ (NSString *)greeting {
    return @"Hello from {{NAME}}!";
}

@end
