#!/bin/sh
# JiangTheos bootstrap_theos.sh —— 设备端一键安装 theos + SDK
export PATH="/var/jb/usr/bin:/var/jb/usr/sbin:/usr/bin:/usr/sbin:/bin:/sbin"
THEOS="${1:-/var/jb/theos}"
echo "== JiangTheos 工具链安装 =="
command -v git >/dev/null 2>&1 || { echo "错误: 未找到 git（请在 Sileo 安装 git 后重试）"; exit 1; }
if [ ! -f "$THEOS/makefiles/common.mk" ]; then
  echo ">> 克隆 theos → $THEOS"
  mkdir -p "$(dirname "$THEOS")"
  git clone --depth 1 --recursive https://github.com/theos/theos.git "$THEOS" || { echo "theos 克隆失败"; exit 1; }
fi
if [ ! -d "$THEOS/sdks/iPhoneOS16.5.sdk" ]; then
  echo ">> 下载 SDK（theos/sdks 仓库，可能较大，请耐心等待）"
  mkdir -p "$THEOS/sdks"
  rm -rf /tmp/theos-sdks
  git clone --depth 1 --filter=blob:limit=50M https://github.com/theos/sdks.git /tmp/theos-sdks 2>/dev/null \
    || git clone --depth 1 https://github.com/theos/sdks.git /tmp/theos-sdks || { echo "SDK 仓库克隆失败"; exit 1; }
  cp -a /tmp/theos-sdks/iPhoneOS16.5.sdk "$THEOS/sdks/" 2>/dev/null \
    || cp -a /tmp/theos-sdks/iPhoneOS*.sdk "$THEOS/sdks/"
  rm -rf /tmp/theos-sdks
fi
echo "== 已安装 SDK: =="
ls "$THEOS/sdks/" 2>/dev/null
echo "== 工具链就绪: $THEOS =="
exit 0
