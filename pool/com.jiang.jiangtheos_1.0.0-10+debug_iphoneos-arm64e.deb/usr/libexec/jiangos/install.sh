#!/bin/sh
# JiangTheos install.sh —— dpkg 安装 + 重载 SpringBoard
export PATH="/var/jb/usr/bin:/var/jb/usr/sbin:/usr/bin:/usr/sbin:/bin:/sbin"
DEB="$1"
[ -f "$DEB" ] || { echo "错误: deb 不存在: $DEB"; exit 1; }
echo "== dpkg -i $DEB =="
dpkg -i "$DEB" || exit 1
echo "== 安装成功，重载 SpringBoard =="
if command -v sbreload >/dev/null 2>&1; then
  sbreload
else
  killall -9 SpringBoard 2>/dev/null
fi
exit 0
